import os
import re

def get_loss_iterations(path = ''):
    # Extract iteration and loss values
    iterations = []
    loss_values = []

    with open(path) as f:
        lines = f.readlines()

    for line in lines:
        if "iteration" in line and "Loss" in line:
            iteration = int(line.split("iteration:")[1].split(":")[0].strip())
            loss = float(line.split("Loss:")[1].split(",")[0].strip())
            iterations.append(iteration)
            loss_values.append(loss)
    
    return iterations, loss_values

def validation_info(path = ''):

    # Initialize lists to store values
    iterations = []
    list_valence_accuracy = []
    list_valence_error_mean = []
    list_valence_error_std = []
    list_arousal_accuracy = []
    list_arousal_error_mean = []
    list_arousal_error_std = []

    # Open and read the text file
    with open(path, 'r') as file:
        content = file.read()


    # Define the pattern to match the desired information
    pattern = re.compile(r"Valence:\s*\n\s*accuracy per clips:\s*([\d.]+)%\s*\n\s*error per clips:\s*mean=([\d.]+),\s*std=([\d.]+)\s*\n\s*Arousal:\s*\n\s*accuracy per clips:\s*([\d.]+)%\s*\n\s*error per clips:\s*mean=([\d.]+),\s*std=([\d.]+)")

    # Find all matches in the log text
    matches = pattern.findall(content)

    # Check if there are any matches and print the results
    if matches:
        for match in matches:
            valence_accuracy, valence_error_mean, valence_error_std, arousal_accuracy, arousal_error_mean, arousal_error_std = match
            #print(f"Valence:\n   accuracy per clips: {valence_accuracy}%\n   error per clips: mean={valence_error_mean}, std={valence_error_std}\nArousal:\n   accuracy per clips: {arousal_accuracy}%\n   error per clips: mean={arousal_error_mean}, std={arousal_error_std}\n")
            list_valence_accuracy.append(float(valence_accuracy))
            list_valence_error_mean.append(float(valence_error_mean))
            list_valence_error_std.append(float(valence_error_std))
            list_arousal_accuracy.append(float(arousal_accuracy))
            list_arousal_error_mean.append(float(arousal_error_mean))
            list_arousal_error_std.append(float(arousal_error_std))
    else:
        print("No matches found.")
    return list_valence_accuracy, list_valence_error_mean, list_valence_error_std, list_arousal_accuracy, list_arousal_error_mean, list_arousal_error_std


if __name__ == '__main__':
    get_loss_iterations()