import cv2
import numpy as np
import torch
import torchvision.transforms as transforms


class TorchImageProcessor:
    """Simple data processors."""

    def __init__(self,
                 image_size,
                 is_color,
                 mean,
                 scale,
                 crop_size=0,
                 pad=28,
                 color="BGR",
                 use_cutout=False,
                 use_mirroring=False,
                 use_random_crop=False,
                 use_center_crop=False,
                 use_random_gray=False):
        
        """Everything that we need to init."""
        self.image_size = image_size
        self.is_color = is_color
        self.mean = mean
        self.scale = scale
        self.crop_size = crop_size
        self.pad = pad
        self.color = color
        self.use_cutout = use_cutout
        self.use_mirroring = use_mirroring
        self.use_random_crop = use_random_crop
        self.use_center_crop = use_center_crop
        self.use_random_gray = use_random_gray
        self.transform = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(mean=self.mean, std=self.scale),
            ]
        )

    def random_crop(self, image):
        """Returns cropped image."""
        image = cv2.copyMakeBorder(
            image,
            self.pad,
            self.pad,
            self.pad,
            self.pad,
            cv2.BORDER_REFLECT_101,
        )
        h, w, _ = image.shape
        top = np.random.randint(0, h - self.crop_size)
        left = np.random.randint(0, w - self.crop_size)
        bottom = top + self.crop_size
        right = left + self.crop_size
        image = image[top:bottom, left:right, :]
        return image
    
    def center_crop(self, image):
        """Returns cropped image."""
        image = cv2.copyMakeBorder(
            image,
            self.pad,
            self.pad,
            self.pad,
            self.pad,
            cv2.BORDER_REFLECT_101,
        )
        h, w, _ = image.shape
        top = (h - self.crop_size) // 2
        left = (w - self.crop_size) // 2
        bottom = top + self.crop_size
        right = left + self.crop_size
        image = image[top:bottom, left:right, :]
        return image
    
    def cutout(self, image):
        """Returns cutout image."""
        image = np.asarray(image).copy()
        h, w, _ = image.shape
        mask = np.ones((h, w, 3), np.float32)
        y = np.random.randint(h)
        x = np.random.randint(w)
        y1 = np.clip(y - self.crop_size // 2, 0, h)
        y2 = np.clip(y + self.crop_size // 2, 0, h)
        x1 = np.clip(x - self.crop_size // 2, 0, w)
        x2 = np.clip(x + self.crop_size // 2, 0, w)
        mask[y1:y2, x1:x2] = 0
        image = image * mask
        return image
    

    def process(self, image_path):
        """Returns processed data."""
        try:
            image = cv2.imread(image_path)
        except:
            image = image_path

        if image is None:
            print(image_path)

        # TODO: реализуйте процедуры аугментации изображений используя OpenCV и TorchVision
        # на выходе функции ожидается массив numpy с нормированными значениям пикселей

        if self.use_random_gray:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)

        if self.use_mirroring:
            image = cv2.flip(image, 1)

        if self.use_random_crop:
            image = self.random_crop(image)

        if self.use_center_crop:
            image = self.center_crop(image)

        if self.use_cutout:
            image = self.cutout(image)

        image = self.transform(image)
        image = image.numpy()

        return image
