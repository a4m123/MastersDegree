import torch
import torch.nn as nn
import torch.nn.functional as F
import sys

sys.path.append("../../")
sys.path.append("../")
sys.path.append("./")
sys.path.append("A:/Профиль/Rab Table/Учёба/3/нейронные сети/4/pytorch/common/")
from common.losses import *

class FeatureExtractor(nn.Module):
    def __init__(self, submodule, extracted_layers):
        super().__init__()
        self.submodule = submodule
        self.extracted_layers = extracted_layers

    def forward(self, data):
        x = data
        for name, module in self.submodule._modules.items():
            if len(module._modules.items()) != 0:
                for name2, module2 in module._modules.items():
                    x = x.squeeze(2)
                    x = module2(x)
            else:
                # print(f'x = {x.shape}, name = {name}')
                # x.shape = [32, 3, 1, 224, 224]. I need to remove 1
                try:
                    x = x.squeeze(2)
                except:
                    pass
                x = module(x)
        #print(x[:5])        
        return x

class CNNNet(nn.Module):
    def __init__(self, num_classes, depth, data_size, emb_name=[], pretrain_weight=None):
        super().__init__()
        sample_size = data_size["width"]
        sample_duration = data_size["depth"]

        # TODO: Реализуйте архитектуру нейронной сети
        net = nn.Sequential()
        net.add_module("conv1", nn.Conv2d(3, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=True))
        net.add_module("bn1", nn.BatchNorm2d(32))
        net.add_module("relu1", nn.ReLU(inplace=True))
        net.add_module("pool1", nn.MaxPool2d(kernel_size=(3, 3)))
        net.add_module("conv2", nn.Conv2d(32, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=True))
        net.add_module("bn2", nn.BatchNorm2d(64))
        net.add_module("relu2", nn.ReLU(inplace=True))
        net.add_module("pool2", nn.MaxPool2d(kernel_size=(3, 3)))
        net.add_module("flatten", nn.Flatten())

        # Fully connected layers
        net.add_module("fc1", nn.Linear(36864, 128))
        net.add_module("relu1", nn.ReLU(inplace=True))
        net.add_module("dropout1", nn.Dropout())

        # Output layer
        net.add_module("output", nn.Linear(128, num_classes))
        net.add_module("softmax", nn.Softmax(dim=1))

        #self.net = net
        self.net = FeatureExtractor(net, emb_name)
        
    def _make_layer(self, block, in_channels, out_channels, kernel_size, stride, padding, use_bn=True, use_dropout=False):
        layers = []
        layers.append(block(in_channels, out_channels, kernel_size, stride, padding, use_bn=use_bn, use_dropout=use_dropout))
        return nn.Sequential(*layers)
    
    def forward(self, data):
        output = self.net(data)
        return output

class CNNNet3D(nn.Module):
    def __init__(self, num_classes, depth, data_size, emb_name=[], pretrain_weight=None):
        super().__init__()
        sample_size = data_size["width"]
        sample_duration = data_size["depth"]

        # TODO: Реализуйте архитектуру нейронной сети
        net = nn.Sequential()
        net.add_module("conv1", nn.Conv3d(3, 64, kernel_size=(3, 7, 7), stride=(1, 2, 2), padding=(1, 3, 3), bias=True))
        net.add_module("bn1", nn.BatchNorm3d(64))
        net.add_module("relu1", nn.ReLU(inplace=True))
        net.add_module("pool1", nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)))

        net.add_module("conv2", nn.Conv3d(64, 128, kernel_size=(3, 3, 3), stride=(1, 1, 1), padding=(1, 1, 1), bias=True))
        net.add_module("bn2", nn.BatchNorm3d(128))
        net.add_module("relu2", nn.ReLU(inplace=True))
        net.add_module("pool2", nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)))

        net.add_module("conv3a", nn.Conv3d(128, 256, kernel_size=(3, 3, 3), stride=(1, 1, 1), padding=(1, 1, 1), bias=True))
        net.add_module("conv3b", nn.Conv3d(256, 256, kernel_size=(3, 3, 3), stride=(1, 1, 1), padding=(1, 1, 1), bias=True))
        net.add_module("bn3", nn.BatchNorm3d(256))
        net.add_module("relu3", nn.ReLU(inplace=True))
        net.add_module("pool3", nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)))

        net.add_module("adaptive_pool", nn.AdaptiveAvgPool3d((1, 1, 1)))
        net.add_module("softmax", nn.Softmax(dim=1))
        
        #self.net = net
        self.net = FeatureExtractor(net, emb_name)
        
    def _make_layer(self, block, in_channels, out_channels, kernel_size, stride, padding, use_bn=True, use_dropout=False):
        layers = []
        layers.append(block(in_channels, out_channels, kernel_size, stride, padding, use_bn=use_bn, use_dropout=use_dropout))
        return nn.Sequential(*layers)
    
    def forward(self, data):
        output = self.net(data)
        return output